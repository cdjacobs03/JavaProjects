package Recursion;

import java.io.IOException;
import java.util.Scanner;

public class multAddition {
 
	public static void main(String[] args) throws IOException {
	 
		Scanner scanner = new Scanner(System.in); // create scanner object
		
		int x , y; // create x and y 
		
		//Read in x and y
		System.out.println("Please enter the first number: ");
		x = scanner.nextInt();
		System.out.println("Please enter the second number: ");
		y = scanner.nextInt();
		
		int product = mult(x,y); //Call mult() method, passing x and y
		
		System.out.println("The product of the two numbers is " + product);
		
		//close scanner
		scanner.close();
 }
	
	public static int mult(int x, int y) { // take in x and y and check cases
		if(x < 0 || y <0) {
			return 0; }
		
		if(x == 1) {
			return y; }
		
		if(y == 1) {
			return x; }
		
		if(x == 0 || y == 0) {
			return 0; }
		
			return( x + mult(x, y-1)); //Recursively call the function by returning 
	}
}
